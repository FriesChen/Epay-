<?php
define('authcode','642490d030f3ff79f99f92d29ecd4bd8');

?>