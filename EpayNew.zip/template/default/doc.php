<?php
if(!defined('IN_CRONLITE'))exit();
?>
<script>window.location.href='/doc/index.html'</script>